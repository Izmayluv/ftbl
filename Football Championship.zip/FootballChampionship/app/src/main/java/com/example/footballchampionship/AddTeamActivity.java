package com.example.footballchampionship;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddTeamActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setContentView(R.layout.activity_add_team);

        EditText editTextNameTeam = findViewById(R.id.editTextNameTeam);
        Button buttonAdd = findViewById(R.id.buttonAdd);
        Button buttonBack = findViewById(R.id.buttonBack);
        DBMatches dbMatches = new DBMatches(this);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dbMatches.insert(editTextNameTeam.getText().toString());
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });*/
    }
}